﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace queue4
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<int> num = new Queue<int>();
            Console.Write("Введите название файла: ");
            string name = Console.ReadLine();
            if (File.Exists(name + ".txt"))
            {
                StreamReader r = File.OpenText("file1.txt");
                while (!r.EndOfStream)
                {
                    string[] m = r.ReadLine().Split(' ');
                    for (int i = 0; i < m.Length; i++)
                    {
                        num.Enqueue(Convert.ToInt32(m[i]));
                    }
                }
                var numbof = from number in num
                             where number > 0
                             select number;
                foreach (int number in num)
                {
                    Console.Write($"{number} ");
                }
            }
            else
            {
                Console.WriteLine("Файл не найден");
            }
            Console.ReadKey();
        }
    }
}
