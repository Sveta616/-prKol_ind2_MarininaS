﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Queue2._8
{
    public partial class Form1 : Form
    {
     Queue<Student> st=new Queue<Student> ();
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader r = File.OpenText("file1.txt");
            while (!r.EndOfStream)
            {
                string[] words = r.ReadLine().Split(' ');
                Student s = new Student();
                s.name1 = words[0];
                s.name2 = words[1];
                s.name3 = words[2];
                s.gr = words[3];
                s.mark1 = Convert.ToInt32(words[4]);
                s.mark2 = Convert.ToInt32(words[5]);
                s.mark3 = Convert.ToInt32(words[6]);
                st.Enqueue(s);
            }
            var h = from s in st
                    orderby s.mark2
                    orderby s.mark3
                    orderby s.mark1
                    select s;
            foreach (Student s in h)
            {
                listBox1.Items.Add($"{s.name1} {s.name2} {s.name3} {s.gr} {s.mark1} {s.mark2} {s.mark3}");
            }
            listBox1.Sorted = true;
        }
    }
    }

